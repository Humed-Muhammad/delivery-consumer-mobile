export const fonts = {
    extraLarge: "30px",
    large: "20px",
    medium: "12px",
    small: "10px",
    extraSmall: "6px",
}