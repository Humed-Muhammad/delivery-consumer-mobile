import OrderList from '@Screen/OrderList';

export const screenList: Array<Object> = [
    {
        name: "Order list",
        component: OrderList,
        title: "List"
    }
]


