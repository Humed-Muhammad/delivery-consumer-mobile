import SplashScreen from "@Screen/SplashScreen"

export const screenList: Array<Object> = [
    {
        name: "Splash",
        component: SplashScreen,
        title: ""
    }
]


