import { AuthenticatedStackNavigation as HomeList } from '@Navigation/AuthenticatedSatckNavigation';
import { OrderStackNavigation as Order } from "@Navigation/OrderStackNavigation"
import Setting from '@Screen/Setting';
import { Icons } from "@Components/Atoms/Icons";
import Language from '@Screen/Language';


export const screenList: Array<Object> = [
    {
        name: "Home",
        component: HomeList,
        title: "Home",
        Icon: Icons
    },
    {
        name: "Order history",
        component: Order,
        title: "Order history",
        Icon: Icons
    },
    {
        name: "Setting",
        component: Setting,
        title: "Setting",
        Icon: Icons
    },
    {
        name: "Language",
        component: Language,
        title: "Language",
        Icon: Icons
    }
]


