import Button from '@Components/Atoms/Button'
import Container from '@Components/Atoms/Container'
import { Icons } from '@Components/Atoms/Icons'
import Image from '@Components/Atoms/Image'
import { Divider } from '@Components/Organisms/Divider'
import { colors } from '@Utils/Color/colors'
import React from 'react'
import { setLanguageType } from '@Redux/Slices/UserSlice'
import { useAppDispatch } from '@Redux/Hooks'

const style = {
    position: "absolute",
    top: 5,
    left: 5
}

const Language = ({ navigation }) => {
    const dispatch = useAppDispatch()
    return (
        <Container direction="column" height="100%">
            <Icons onPress={() => navigation.navigate("Home")} color={colors.gray} size={30} name="arrow-back" style={style} />
            <Image imageWidth={50} imageHeight={50} source={require("@Assets/Images/language.png")} />
            <Container width="60%" direction="column">
                <Button onPress={() => {
                    dispatch(setLanguageType("English"))
                    navigation.goBack()
                }} color={colors.gray} bg={colors.white} text="English" />
                <Divider thikness={0.5} color={colors.icon} />
                <Button onPress={() => {
                    dispatch(setLanguageType("Amharic"))
                    navigation.goBack()
                }} color={colors.gray} bg={colors.white} text="Amharic" />
                <Divider thikness={0.5} color={colors.icon} />

                <Button onPress={() => {
                    dispatch(setLanguageType("Afan oromo"))
                    navigation.goBack()
                }} color={colors.gray} bg={colors.white} text="Afan oromo" />
            </Container>
        </Container>
    )
}

export default Language
