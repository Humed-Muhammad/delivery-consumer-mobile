import Button from '@Components/Atoms/Button'
import Container from '@Components/Atoms/Container'
import Image from '@Components/Atoms/Image'
import Input from '@Components/Atoms/Inputs'
import React, { useState } from 'react'
import { ScrollView } from 'react-native'
import FilePicker from "@Components/Organisms/FilePicker"
import CardConatiner from '@Components/Atoms/CardContainer'
import { useAppSelector } from "@Redux/Hooks"
import { userProfileData as data } from '@Redux/MemoizedSelectors'
import Address from './Address'
import Loader from '@Components/Organisms/Loader'

const Profile = () => {
    const userProfileData = useAppSelector(data)
    const [loading, setLoading] = useState(false)

    return (
        <ScrollView style={{ marginTop: 60 }}>
            <Container justify="flex-start" direction="column" height="650px">
                <Container>
                    <FilePicker setLoading={setLoading} />
                    {loading ? (<Loader height="250px" width="90%" />) : (<Image radius={5} imageHeight={250} imageWidth="90%" source={{ uri: userProfileData.profileImage }} />)}
                </Container>
                <CardConatiner radius="2px" bottom="20px" position="absolute" justify="space-evenly" width="90%" height="55%" direction="column">
                    <Input value={userProfileData.fullName} radius="0px" borderWidth="0px" borderBottomWidth={1} width="85%" placeholder="Full Name" />
                    <Input value={userProfileData.email} radius="0px" borderWidth="0px" borderBottomWidth={1} width="85%" placeholder="Email" />
                    <Input value={userProfileData.phoneNumber} radius="0px" borderWidth="0px" borderBottomWidth={1} width="85%" placeholder="Phone Number" />
                    <Input value={userProfileData.location} radius="0px" borderWidth="0px" borderBottomWidth={1} width="85%" placeholder="Location" />
                    <Button width="90%" text="Save" />
                </CardConatiner>
            </Container>
            <Address />
        </ScrollView>
    )
}

export default Profile
