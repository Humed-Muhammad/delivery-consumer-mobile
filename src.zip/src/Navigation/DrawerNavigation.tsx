import React, { useEffect, useState } from "react";
import { createDrawerNavigator, DrawerItem, DrawerItemList } from "@react-navigation/drawer"
import { screenList } from "@Routes/DrawerNavigationList"
import Container from "@Components/Atoms/Container";
import Image from "@Components/Atoms/Image";
import Text from "@Components/Atoms/Text";
import { colors } from "@Utils/Color/colors";
import { ScrollView } from "react-native-gesture-handler";
import Navbar from "@Components/Organisms/Navbar";
import { Icons } from "@Components/Atoms/Icons";
import { getJsonData, removeData } from "@Utils/AccessStorage";
import { loggeIn } from "@Redux/Slices/AccountSlice";
import { useAppDispatch } from "@Redux/Hooks";
import { View } from "react-native";
import { resetPickup } from "@Redux/Slices/PickUpSlice";

const style = {
    backgroundColor: colors.white,
    height: 45,
    width: 45,
    borderRadius: 50,
    margin: 10,
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    offSet: { width: -2, height: 4 },
    elevation: 5
}



const Drawer = createDrawerNavigator();
const iconNames = ["home", "pending", "settings", "language"]

const drawerIcon = (navigation) => {
    return (
        <View >
            <Icons style={style} onPress={() => navigation.openDrawer()} color={colors.gray} name="menu" size={25} />
        </View>
    )
}

const screens = screenList.map(({ name, component, Icon, title }: any, index) => (
    <Drawer.Screen
        key={index}
        name={name}
        component={component}
        options={{
            drawerIcon: () => <Icon size={30} name={iconNames[index]} />,
            header: ({ navigation }) => (name == "Home") ? drawerIcon(navigation) : <Navbar title={title} navigation={navigation} />,
            headerTransparent: true,
        }}
    />
))


const CustomDrawerContent = (props) => {
    const [userData, setUserData] = useState<any>(null)
    const dispatch = useAppDispatch()

    useEffect(() => {
        const fetchData = async () => {
            const data = await getJsonData("user_data");
            setUserData(await data)
        }
        fetchData()
        return () => {
            setUserData("")
        }
    }, [])
    return (
        <ScrollView {...props}>
            <Container bg={colors.border} direction="column" justify="space-evenly" height="200px">
                <Image imageHeight={100} imageWidth={100} radius={50} source={{ uri: "https://cdn.now.howstuffworks.com/media-content/0b7f4e9b-f59c-4024-9f06-b3dc12850ab7-1920-1080.jpg" }} />
                <Text color={colors.gray} fontSize="15px" fontWeight="bold">Hi {`${userData && userData["message"]["full_name"]}`.toLocaleUpperCase()}</Text>
            </Container>
            <DrawerItemList {...props} />
            <DrawerItem
                onPress={async () => {
                    await removeData("user_data")
                    dispatch(loggeIn(false))
                    dispatch(resetPickup())
                    dispatch(resetPickup())
                }}
                icon={() =>
                    <Icons style={null} size={30} name="power-settings-new" />
                }
                label="Logout"
            />
        </ScrollView>
    );
}



export const DrawerNavigation = () => {
    return (
        <Drawer.Navigator drawerContent={(props) => <CustomDrawerContent {...props} />}>
            {screens}
        </Drawer.Navigator>
    )
}